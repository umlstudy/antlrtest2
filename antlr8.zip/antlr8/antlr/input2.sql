SELECT 
  
  /*+ TbbdBatChkRdsS001_Select */
  case when count(ERR) = 0 then 'Y' else 'N' end AS DATA_VALID_YN -- Y:���� 
FROM 
  (
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    WHERE 
      MKT_ID >= (
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0001'
      ) 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
      --SELECT case when count(*)>0 then null else 1 end ERR FROM TBBD_BAS_INT union all
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- WHERE DD >= (SELECT SETL_DD FROM TBBD_SETL_DD_INFO WHERE MKT_ID='KTS') union all -- 2014.04.07 -- 2015.11.16 �ּ�ó�� 
    WHERE 
      DD >= (
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0001'
      ) 
    union all 
      -- 2014.04.07 -- 2015.11.16 ���� 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
      --SELECT case when count(*)>0 then null else 1 end ERR FROM TBBD_MKT_BRD_ADM_INFO union all 
      --SELECT case when count(*)>0 then null else 1 end ERR FROM TBBD_MKT_CD_INFO union all
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
      --SELECT case when count(*)>0 then null else 1 end ERR FROM TBBD_SETL_DD_INFO union all -- 2015.11.16
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
      --SELECT case when count(*)>0 then null else 1 end ERR FROM TBBD_QTY_LMT union all
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- 2015.07.27WHERE CD_ID = '1001' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0015' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- 2015.07.27
    WHERE 
      CD_ID = '1002' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0015' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- 2015.07.27
    WHERE 
      CD_ID = '1002' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0014' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
      --SELECT case when count(*)>0 then null else 1 end ERR FROM TBBD_ISU_HIST union all
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- 2015.07.27
    WHERE 
      CD_ID = '001' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0015' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- 2015.07.27
    WHERE 
      CD_ID = '001' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0014' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- 2015.07.27
    WHERE 
      CD_ID = '011' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0015' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- 2015.07.27
    WHERE 
      CD_ID = '012' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0015' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- 2015.07.27
    WHERE 
      CD_ID = '013' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0015' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
      --SELECT case when count(*)>0 then null else 1 end ERR FROM TBBD_INFLLNK_FACTR 
      -- WHERE DD >= (SELECT SETL_DD FROM TBBD_SETL_DD_INFO WHERE MKT_ID='KTS') union all 
      -- 2014.04.07 
      ---- WHERE DD >= (SELECT MKT_ID FROM TBBD_SYS_ADM WHERE CD_ID='0001') union all -- 2014.04.07 
      -- �������������� ���, �ش� �������� ������������� �� �־�� �� 
    SELECT 
      case when COUNT(*) = 0 
      or SUM(
        NVL2(C.INFLLNK_FACTR, 0, 1)
      ) = 0 then null else 1 end ERR -- 2015.11.16 LKS
    FROM 
      DUAL A, 
      DUAL B, 
      DUAL C 
    WHERE 
      A.INFLLNK_YN = 'Y' 
      AND A.ISU_CD = B.ISU_CD
      AND B.ISU_CD = C.ISU_CD(+) 
      AND B.SETL_DD = C.DD(+) 
    union all 
      -- 2015.11.16 PJH -- TBBD_MKT_BRD_ISU_INFO �� �������� ���ϰ� ���ų� Ŀ�� ��!! -- TBBD_MKT_BRD_ISU_INFO �� �������� NULL �̸� ���� -- TBBD_MKT_BRD_ISU_INFO �� �������� ���Ϲ̸� �̸� ���� 
    SELECT 
      case when count(
        case when SETL_DD is null 
        OR SETL_DD <(
          SELECT 
            MKT_ID 
          FROM 
            DUAL 
          WHERE 
            CD_ID = '0001'
        ) then 'err' else null end
      ) = 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
      -- 2015.11.16 PJH -- TBBD_CM_ISU_INFO �� WI ������ ������, �� ���� ���� ���ེ������ �����Ͽ� �������� �ݿ��� TBBD_MKT_BRD_ISU_INFO �� �������� ���ϰ� ���ų� Ŀ����!! -- WI ������ �ִµ� ���ེ������ �ȿ����� TBBD_MKT_BRD_ISU_INFO �� �������� NULL �� �� �̹Ƿ� ���� -- WI ������ �ִµ� ���ེ������ �Դµ�, TBBD_MKT_BRD_ISU_INFO �� �������� NULL �̸� ���� -- WI ������ �ִµ� ���ེ������ �Դµ�, TBBD_MKT_BRD_ISU_INFO �� �������� ���Ϲ̸� �̸� ���� 
    SELECT 
      case when count(
        case when A.BID_CLS_DD is null 
        OR A.BID_CLS_DD <(
          SELECT 
            MKT_ID 
          FROM 
            DUAL 
          WHERE 
            CD_ID = '0001'
        ) then 'err' else null end
      ) = 0 then null else 1 end ERR 
    FROM 
      DUAL A, 
      DUAL B 
    WHERE 
      A.ISU_CD = B.ISU_CD
      AND B.GOVBND_ISU_TP_CD = 'W' 
      AND A.HALT_YN = 'N' 
    union all 
      -- 2015.11.16 PJH -- ��ü�ῡ Ȯ���� ������ �ִµ��� TBBD_MKT_BRD_ISU_INFO �� ������ ���� ��� ���� 
    SELECT 
      case when count(*)> 0 then 1 else null end ERR 
    FROM 
      DUAL A 
    WHERE 
      A.FINAL_YN <> 'Y' 
      AND NOT EXISTS (
        SELECT 
          * 
        FROM 
          DUAL B 
        WHERE 
          B.MKT_ID = A.MKT_ID 
          AND B.BRD_ID = 'G1' 
          AND B.ISU_CD = A.ISU_CD
      ) 
    union all 
      -- ����ü�� ���� BRD_ID �� G1 -- 2015.11.16 PJH -- ��ü�ῡ ������ �Ǵ� �������� NULL �� ������ ������ ���� (Ȯ������ ���ؼ��� �ص� �ǰ����� ������ ���鿡�� ��ü�� ���� ����) 
    SELECT 
      case when count(*)> 0 then 1 else null end ERR 
    FROM 
      DUAL 
    WHERE 
      BID_CLS_DD is null 
      OR SETL_DD is null 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    WHERE 
      DD >= (
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0001'
      ) 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    WHERE 
      CD_ID = '011' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0015' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- 2015.07.27
    WHERE 
      CD_ID = '012' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0015' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL -- 2015.07.27
    WHERE 
      CD_ID = '012' -- 2015.07.27
      AND MKT_ID =(
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0014' 
          AND MKT_ID = 'Y'
      ) 
    union all 
      -- 2015.07.27
    SELECT 
      case when count(*)> 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
      --SELECT case when count(*)>0 then null else 1 end ERR FROM TBBD_MBR_HIST union all --SELECT case when count(*)>0 then null else 1 end ERR FROM TBBD_BYMBR_SEQ_ADM union all --SELECT case when count(*)>0 then null else 1 end ERR FROM TBBD_TRDR_ADM_INFO union all -- �Է��� �Է����ڰ� �������������� ���� ���� ū �����Ͱ� �����ϸ� �ȵ� 
    SELECT 
      case when count(*)= 0 then null else 1 end ERR 
    FROM 
      DUAL 
    WHERE 
      INPUT_DD > (
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0181'
      ) 
    union all 
      -- �Է��� �Է����ڰ� �������������� ���� ���� ū �����Ͱ� �����ϸ� �ȵ� 
    SELECT 
      case when count(*)= 0 then null else 1 end ERR 
    FROM 
      DUAL 
    WHERE 
      INPUT_DD > (
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        WHERE 
          CD_ID = '0181'
      ) 
    union all 
    SELECT 
      case when count(*)= 0 then null else 1 end ERR 
    FROM 
      DUAL 
    union all 
      --SELECT case when count(*)=0 then null else 1 end ERR FROM TBBD_ACNT_INFO union all -- ���� �����߰��� count(*)>0 -- 2016.03.28 ���¼��� --SELECT case when count(*)=0 then null else 1 end ERR FROM TBBD_TRDR_ACNT_INFO union all -- ���� �����߰��� count(*)>0 -- 2016.03.28 ���¼��� 
    SELECT 
      case when A.CNT = B.CNT then null else 1 end 
    FROM 
      (
        SELECT 
          COUNT(*)-3 AS CNT 
        FROM 
          DUAL
      ) A, 
      (
        SELECT 
          COUNT(DISTINCT ISU_CD) AS CNT 
        FROM 
          DUAL
      ) B 
    union all 
    SELECT 
      case when COUNT(*) = 0 then null else 1 end ERR 
    FROM 
      (
        SELECT 
          MKT_ID 
        FROM 
          DUAL 
        GROUP BY 
          MKT_ID 
        HAVING 
          COUNT(*) = 0
      ) 
    union all 
    SELECT 
      case when COUNT(*) = 0 then null else 1 end ERR 
    FROM 
      (
        SELECT 
          MKT_ID, 
          BRD_ID 
        FROM 
          DUAL 
        GROUP BY 
          MKT_ID, 
          BRD_ID 
        HAVING 
          COUNT(*) = 0
      ) ---------------------------------------------------------------------2016.03.28 start 
      )
